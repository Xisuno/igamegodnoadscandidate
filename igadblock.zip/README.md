# IGAdBlock
Rootless Theos tweak (arm64/arm64e, iOS 15+ target) that discovers and blocks ad SDK methods in one app, driven by a config plist.

1. Set the repo variable `IGAMEGOD_BUNDLE_ID` (Settings > Secrets and variables > Actions > Variables), or pass `bundle_id` when running Build manually.
2. Push to `main` or run **Build**; download the `.deb` from the run's artifacts.
3. Or commit a zip of the project into `upload/`; **Unzip upload** unpacks it and triggers a build.

Config on device: `/var/jb/Library/Application Support/IGAdBlock/config.plist` (mode `discover` or `block`).
