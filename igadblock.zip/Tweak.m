#import <Foundation/Foundation.h>
#import <objc/runtime.h>

static NSString *const kConfigPath = @"/var/jb/Library/Application Support/IGAdBlock/config.plist";
static NSDictionary *gConfig;
static NSSet<NSString *> *gBlockedHosts;

static void Log(NSString *s) { NSLog(@"[IGAdBlock] %@", s); }

static NSDictionary *LoadConfig(void) {
    NSDictionary *c = [NSDictionary dictionaryWithContentsOfFile:kConfigPath];
    if (!c) { Log(@"config unreadable (missing file or sandbox denies path)"); return nil; }
    NSString *want = c[@"bundleID"];
    if (![want isKindOfClass:NSString.class] || ![want isEqualToString:NSBundle.mainBundle.bundleIdentifier]) return nil;
    return c;
}

// Discovery: ad-SDK name prefixes are common conventions, not a claim about iGameGod.
static void Discover(void) {
    NSArray *prefixes = gConfig[@"discoverPrefixes"] ?: @[@"GAD", @"GAM", @"UADS", @"UnityAds", @"IS", @"FBAd", @"FBInterstitial", @"FBBanner", @"BU", @"MT", @"AL", @"MP", @"Vungle", @"VNG", @"APD"];
    NSArray *words = @[@"load", @"show", @"present", @"request", @"fetch", @"display"];
    unsigned n = 0;
    Class *list = objc_copyClassList(&n);
    for (unsigned i = 0; i < n; i++) {
        NSString *name = @(class_getName(list[i]));
        BOOL hit = NO;
        for (NSString *p in prefixes) if ([name hasPrefix:p]) { hit = YES; break; }
        if (!hit) continue;
        for (int meta = 0; meta < 2; meta++) {
            Class k = meta ? object_getClass(list[i]) : list[i];
            unsigned mc = 0;
            Method *ms = class_copyMethodList(k, &mc);
            for (unsigned j = 0; j < mc && j < 400; j++) {
                NSString *sel = NSStringFromSelector(method_getName(ms[j]));
                for (NSString *w in words) {
                    if ([sel.lowercaseString containsString:w]) {
                        Log([NSString stringWithFormat:@"%@[%@ %@] enc=%s", meta ? @"+" : @"-", name, sel, method_getTypeEncoding(ms[j])]);
                        break;
                    }
                }
            }
            free(ms);
        }
    }
    free(list);
}

static void BlockMethod(NSString *clsName, NSString *selName, BOOL meta) {
    Class c = NSClassFromString(clsName);
    if (!c) { Log([@"class not loaded yet: " stringByAppendingString:clsName]); return; }
    if (meta) c = object_getClass(c);
    Method m = class_getInstanceMethod(c, NSSelectorFromString(selName));
    if (!m) { Log([NSString stringWithFormat:@"selector not found: %@ %@", clsName, selName]); return; }
    const char *enc = method_getTypeEncoding(m);
    char r = enc ? enc[0] : 0;
    IMP imp = NULL;
    if (r == 'v') imp = imp_implementationWithBlock(^(id s) {});
    else if (r == '@') imp = imp_implementationWithBlock(^id(id s) { return nil; });
    else if (r == 'B') imp = imp_implementationWithBlock(^BOOL(id s) { return NO; });
    if (!imp) { Log([NSString stringWithFormat:@"unsupported return type '%c' for %@ %@", r, clsName, selName]); return; }
    method_setImplementation(m, imp);
    Log([NSString stringWithFormat:@"blocked %@ %@", clsName, selName]);
}

static void ApplyBlocks(void) {
    for (NSDictionary *e in gConfig[@"block"]) {
        if (![e isKindOfClass:NSDictionary.class]) continue;
        NSString *c = e[@"class"], *s = e[@"selector"];
        if (!c || !s) continue;
        BlockMethod(c, s, [e[@"classMethod"] boolValue]);
    }
}

// Host blocking via URL rewrite to a dead local port.
static NSURL *Dead(void) { return [NSURL URLWithString:@"http://127.0.0.1:1/"]; }
static BOOL Blocked(NSURL *u) { return u.host && [gBlockedHosts containsObject:u.host.lowercaseString]; }

static void HookSession(void) {
    if (!gBlockedHosts.count) return;
    Class k = NSClassFromString(@"__NSURLSessionLocal") ?: NSURLSession.class;
    SEL s1 = @selector(dataTaskWithRequest:completionHandler:);
    Method m1 = class_getInstanceMethod(k, s1);
    if (m1) {
        IMP o = method_getImplementation(m1);
        method_setImplementation(m1, imp_implementationWithBlock(^id(id self, NSURLRequest *r, id h) {
            if (Blocked(r.URL)) { Log([@"host blocked: " stringByAppendingString:r.URL.host]); r = [NSURLRequest requestWithURL:Dead()]; }
            return ((id(*)(id, SEL, id, id))o)(self, s1, r, h);
        }));
    }
    SEL s2 = @selector(dataTaskWithURL:completionHandler:);
    Method m2 = class_getInstanceMethod(k, s2);
    if (m2) {
        IMP o = method_getImplementation(m2);
        method_setImplementation(m2, imp_implementationWithBlock(^id(id self, NSURL *u, id h) {
            if (Blocked(u)) { Log([@"host blocked: " stringByAppendingString:u.host]); u = Dead(); }
            return ((id(*)(id, SEL, id, id))o)(self, s2, u, h);
        }));
    }
}

static void Pass(void) {
    if ([gConfig[@"mode"] isEqualToString:@"discover"]) Discover();
    else ApplyBlocks();
}

__attribute__((constructor)) static void Init(void) {
    @autoreleasepool {
        gConfig = LoadConfig();
        if (!gConfig) return;
        gBlockedHosts = [NSSet setWithArray:gConfig[@"blockedHosts"] ?: @[]];
        HookSession();
        Pass();
        for (NSNumber *d in @[@3, @10, @30])
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, d.intValue * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ Pass(); });
    }
}
